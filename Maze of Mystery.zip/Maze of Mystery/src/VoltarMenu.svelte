<script>
	import { trocarEstadoDoJogo } from './Estado.js'
</script>

<button class='menu' on:click={() => trocarEstadoDoJogo('menu')}>
	Voltar ao Menu
</button>