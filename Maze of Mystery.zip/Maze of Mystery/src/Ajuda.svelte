<svelte:head>
	<link rel="stylesheet" href="/styles/ajuda.css">
</svelte:head>

<script>
	import VoltarMenu from './VoltarMenu.svelte'
</script>

<h1 class= ajuda>
	 Ajuda
	
	</h1>

	<p> 
		<b>Use as setinhas do teclado (Arrows keys) as famosas cima,baixo,esquerda e direita </b>
	</p>

	<VoltarMenu/>
