<svelte:head>
	<link rel="stylesheet" href="/styles/sobre.css">
</svelte:head>

<script>
	import VoltarMenu from './VoltarMenu.svelte'
</script>

<h1 class= "nham">
	
		Sobre
	

	</h1>

<img src="images/logoIFPE.png" alt="logo IPFE"/>

<p>
	<b> Alyson Alves Pestana<br>
		Edimilly Hadassa da Silva<br>
		Elouyse Victória Machado da Silva<br>
		Júlio César Silva do Nascimento<br>
		Wellington Ramos Da Silva</b>


</p>

<VoltarMenu/>
